﻿using System;


namespace scoringTennis
{
    class Program
    {
        static void Main(string[] args)
        {
            

            int score1 = 0, score2 = 0;

            while (score1 <= 40 || score2 <=40)
            {

                string asignar = asignarPuntos();
                if (asignar.Equals("player1"))
                {
                    score1++;
                    Console.WriteLine(EstadoScore(score1));
                }
                else
                {
                    score2++;
                    Console.WriteLine(EstadoScore(score2));

                }
                //Console.WriteLine(asignar);
               // Console.WriteLine(EstadoScore(score1) + "  " + EstadoScore(score2));
                if (score1 == 40)
                {
                    Console.WriteLine("GANADOR");
                    break;
                }else if(score2 == 40)
                {
                    Console.WriteLine("GANADOR");
                    break;
                }
                else if(score1== score2)
                {
                    Console.WriteLine("EMPATE");
                    break;
                }



            }

           
        }


        public static string asignarPuntos()
        {

            Random rnd = new Random();
            string[] player = { "player1", "player2" };
            int playerIndex = rnd.Next(player.Length);

            return player[playerIndex];

        }

        public static string EstadoScore(int points)
        {

            switch (points)
            {
                case 3:
                    return "40";
                case 2:
                    return "30";
                case 1:
                    return "15";
                case 0:
                    return "0";
                default:
                    return "juego";
            }
            
        }
    }
}
